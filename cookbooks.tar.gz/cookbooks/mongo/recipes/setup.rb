#Chef::Log.info('HELLO')
#Chef::Log.info(node[:database][:host])
#yml_string = YAML::dump(node[:apache].to_hash)
#Chef::Log.info(yml_string)